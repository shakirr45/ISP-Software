<!-- Footer Start -->
<footer class="d-footer">
    <div class="row align-items-center justify-content-between">
        <div class="col-auto">
            <p class="mb-0">© <script>
                    document.write(new Date().getFullYear())
                </script> BSD. All Rights Reserved.</p>
        </div>
        <div class="col-auto">
            <p class="mb-0">Made by <span class="text-primary-600"><a href="https://bsdbd.com/" target="_blank">BSDBD</a></span></p>
        </div>
    </div>
</footer>
<!-- end Footer -->