<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="A powerful admin dashboard designed exclusively for ISP management. Developed by a dedicated Bangladeshi software development team, this solution ensures efficiency, reliability, and customization for your business needs." name="description" />
<meta content="BSD" name="author" />
<title><?php echo $title ?> | ISP Management Admin Dashboard</title>
<link rel="icon" type="image/png" href="assets/images/bsd/logo.png" sizes="16x16">