<?php
    define('HOST','localhost');
	define('USER','bsdbdxyz_new_isp');
	define('PASS','n,hkTXt@LDMK');
	define('DB','bsdbdxyz_new_isp');
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>